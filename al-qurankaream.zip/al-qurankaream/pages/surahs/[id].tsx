
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";

const SurahDetail = () => {
  const router = useRouter();
  const { id } = router.query;
  const [verses, setVerses] = useState([]);
  const [surahName, setSurahName] = useState("");

  useEffect(() => {
    if (id) {
      fetch(\`https://api.alquran.cloud/v1/surah/\${id}/en.asad\`)
        .then(res => res.json())
        .then(data => {
          setVerses(data.data.ayahs);
          setSurahName(data.data.englishName);
        });
    }
  }, [id]);

  return (
    <main className="min-h-screen bg-white text-green-900 py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">{surahName}</h1>
      <div className="max-w-3xl mx-auto space-y-6">
        {verses.map(ayah => (
          <div key={ayah.number} className="bg-green-50 p-4 rounded shadow">
            <p className="text-lg">{ayah.text}</p>
            <p className="text-sm text-gray-600 text-right">Ayah {ayah.numberInSurah}</p>
          </div>
        ))}
      </div>
    </main>
  );
};

export default SurahDetail;
