
import React, { useEffect, useState } from "react";
import Link from "next/link";

const SurahsPage = () => {
  const [surahs, setSurahs] = useState([]);

  useEffect(() => {
    fetch("https://api.alquran.cloud/v1/surah")
      .then(res => res.json())
      .then(data => setSurahs(data.data));
  }, []);

  return (
    <main className="min-h-screen bg-white text-green-900 py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">📖 All Surahs</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
        {surahs.map(surah => (
          <Link href={`/surahs/${surah.number}`} key={surah.number}>
            <a className="p-4 bg-green-100 hover:bg-green-200 rounded-lg shadow text-center font-medium transition">
              {surah.englishName} ({surah.englishNameTranslation})
            </a>
          </Link>
        ))}
      </div>
    </main>
  );
};

export default SurahsPage;
