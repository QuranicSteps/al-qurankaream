
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { motion } from "framer-motion";

const HomePage = () => {
  const [dailyVerse, setDailyVerse] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const fetchVerseOfTheDay = async () => {
      try {
        const today = new Date();
        const day = today.getDate();
        const response = await fetch(`https://api.alquran.cloud/v1/ayah/${day}/en.asad`);
        const data = await response.json();
        setDailyVerse(data.data);
      } catch (error) {
        console.error("Error fetching daily verse:", error);
      }
    };
    fetchVerseOfTheDay();
  }, []);

  return (
    <main className="min-h-screen bg-gradient-to-b from-green-100 to-white text-gray-800">
      <section className="text-center py-16 bg-green-800 text-yellow-200">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-4xl font-bold"
        >
          Welcome to al-Quran Kaream
        </motion.h1>
        <p className="mt-4 text-lg">Gain knowledge and reflect upon the words of Allah</p>
      </section>

      <section className="max-w-4xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-semibold text-green-900 mb-6">🌟 Reflection of the Day</h2>
        {dailyVerse ? (
          <div className="bg-white p-6 rounded-xl shadow-xl">
            <p className="text-xl font-medium text-green-800 mb-4">
              {dailyVerse.text}
            </p>
            <p className="text-sm text-gray-600">
              Surah {dailyVerse.surah.englishName} ({dailyVerse.surah.englishNameTranslation}) - Ayah {dailyVerse.numberInSurah}
            </p>
          </div>
        ) : (
          <p>Loading daily verse...</p>
        )}
      </section>

      <section className="text-center py-10">
        <button
          onClick={() => router.push("/surahs")}
          className="bg-green-700 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-2xl shadow-lg transition"
        >
          📖 Explore All Surahs
        </button>
      </section>
    </main>
  );
};

export default HomePage;
